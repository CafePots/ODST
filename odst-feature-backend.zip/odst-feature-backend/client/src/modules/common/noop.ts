/**
 * The most useful function that does absolutely nothing.
 */
export default function noop() { }
