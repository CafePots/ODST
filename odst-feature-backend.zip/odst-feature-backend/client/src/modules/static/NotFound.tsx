export default function NotFound() {
  return (
    <>
      <h1 data-testid="404">404 Not Found</h1>
      <p>This is not the page you are looking for....</p>
    </>
  );
}
